=====================================================================
# DOCUMENTATION FOR: GLOBAL PROFILES FOR INTERNAL DISPLACEMENT (GPID)
=====================================================================

---------------------------------------------------------------------
VERSION
---------------------------------------------------------------------

Dataset version: March 2025

---------------------------------------------------------------------
CITATION
---------------------------------------------------------------------

If you use this dataset, please cite: [...]


---------------------------------------------------------------------
CONTACT
---------------------------------------------------------------------

For questions, contact: rbeyer@iom.int


---------------------------------------------------------------------
DATASET STRUCTURE
---------------------------------------------------------------------

The dataset is provided at three spatial scales:
- Data_global.csv
- Data_regional.csv
- Data_national.csv


---------------------------------------------------------------------
REGIONAL GROUPING
---------------------------------------------------------------------

In Data_regional.csv, the following 8 regions are used:

- Central and Southern Asia
- Eastern and South-Eastern Asia
- Europe
- Latin America and the Caribbean
- Northern Africa and Western Asia
- Northern America
- Oceania
- Sub-Saharan Africa


---------------------------------------------------------------------
COLUMN DESCRIPTIONS
---------------------------------------------------------------------

Area
----
- In Data_global.csv:   always 'World'
- In Data_regional.csv: one of the 8 regions listed above
- In Data_national.csv: a country name

AreaCode
--------
- ISO 3166-1 alpha-3 country codes
- Only included in Data_national.csv: 

Year
----
- An integer between 2018 and 2024
- Or '2018-2024' for when all years were included in the analysis

Cause
-----
The cause of the displacement.
Includes both specific causes and the following aggregates:
- 'All':             all causes
- 'Disaster':        all non-conflict causes
- 'WeatherDisaster': all weather-related causes
                     (Flood, Storm, Wildfire, Drought, Erosion,
                      Extreme temperature, Wave action, Sea level rise)

Displacements
-------------
Number of recorded displacements for the specified area, year(s), and cause(s)


---------------------------------------------------------------------
DEMOGRAPHIC & SOCIO-ECONOMIC VARIABLES
---------------------------------------------------------------------

NOTE:
"Impacted populations" refers to populations living in the locations of displacements
of the specified cause(s) in the specified area in the specified year(s).

"Average ... across impacted populations/locations" refers to the weighted median
across relevant displacement events. Weights are given by the number of displacements
of each event.

-------------------------
Demographic Variables
-------------------------

Age
- Average age across impacted populations
- Unit: years

Females
- Average percentage of women and girls across impacted populations
- Unit: percent

Males
- Average percentage of men and boys across impacted populations
- Unit: percent

Infants
- Average percentage of under-1-year-olds across impacted populations
- Unit: percent

Children
- Average percentage of under-18-year-olds across impacted populations
- Unit: percent

Elders
- AAverage percentage of over-65-year-olds across impacted populations
- Unit: percent

-------------------------
Socio-Economic Variables
-------------------------

Income
- Average per-capita annual Gross National Income across impacted populations
- Unit: constant 2017 US dollars (per year)

Education
- Average mean number of schooling years across impacted populations
- Unit: years

Health
- Average mean life expectancy across impacted populations
- Unit: years

-------------------------
Land Use Variables
-------------------------

Cropland
- Average percentage of cropland (of total land area) across impacted locations
- Unit: percent

GrazingLand
- Average percentage of grazing land (of total land area) across impacted locations
- Unit: percent

UrbanLand
- Average percentage of urban land (of total land area) across impacted locations
- Unit: percent

IndigenousLand
- Average percentage of land managed and/or controlled by Indigenous Peoples across impacted locations
- Unit: percent
- Not included in Data_national.csv

